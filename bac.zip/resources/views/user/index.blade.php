@extends('layouts.app')

@section('title', 'Dashboard User')

@section('content')
<h1>Selamat Datang di Dashboard User</h1>
<p>Konten untuk user di sini.</p>
@endsection
