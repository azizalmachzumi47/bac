@extends('layouts.app')

@section('title', 'Dashboard')

@section('content')
<h1>Selamat Datang di Dashboard</h1>
<p>Konten</p>
@endsection
