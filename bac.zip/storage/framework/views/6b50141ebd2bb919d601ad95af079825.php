

<?php $__env->startSection('content'); ?>
<div class="container">  
    <h3>Image for Service: <?php echo e($service->category); ?></h3>  
  
    <a href="<?php echo e(route('service.image_activity')); ?>" class="btn btn-secondary mb-3">Back to List</a>

    <?php if(session('success')): ?>
        <div class="alert alert-success"><?php echo e(session('success')); ?></div>
    <?php endif; ?>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID Image</th>
                <th>ID Service</th>
                <th>Activity Photos BAC</th>
                <th>Action</th>
            </tr>
        </thead>
        <tbody>
            <?php $__empty_1 = true; $__currentLoopData = $images; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $img): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
                <td><?php echo e($img->id_imageactivity); ?></td>
                <td><?php echo e($img->id_service); ?></td>
                <td>
                    <?php if($img->activity_photosbac): ?>
                        <img src="<?php echo e(asset('activityphotos_bac/' . $img->activity_photosbac)); ?>" alt="Activity Photos BAC" style="max-width: 150px;">
                    <?php else: ?>
                        <span>Tidak ada gambar</span>
                    <?php endif; ?>
                </td>
                <td>
                    <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#deleteModal<?php echo e($img->id_imageactivity); ?>">
                        <i class="fas fa-trash"></i> Delete
                    </button>
                </td>
            </tr>

            <!-- Modal Delete -->
            <div class="modal fade" id="deleteModal<?php echo e($img->id_imageactivity); ?>" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel<?php echo e($img->id_imageactivity); ?>" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <form action="<?php echo e(route('service.deleteimageactivity', $img->id_imageactivity)); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="deleteModalLabel<?php echo e($img->id_imageactivity); ?>">Konfirmasi Hapus Gambar</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                  <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body text-center">
                                <p>Apakah Anda yakin ingin menghapus gambar ini?</p>
                                <?php if($img->activity_photosbac): ?>
                                    <img src="<?php echo e(asset('activityphotos_bac/' . $img->activity_photosbac)); ?>" alt="Preview" class="img-fluid" style="max-width: 100%;">
                                <?php endif; ?>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-danger">Delete</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>

            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
                <td colspan="4">Tidak ada gambar yang ditemukan.</td>
            </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\laravel\bac\resources\views/service/view_images.blade.php ENDPATH**/ ?>