

<?php $__env->startSection('title', 'Company Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <a href="" class="btn btn-primary mb-3" data-toggle="modal" data-target="#newAddModal">
            Add New Superiority
        </a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-bordered first">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Title</th>
                        <th scope="col">Decryption</th>
                        <th scope="col">image_superiority</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $superioritys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($sy->title); ?></td>
                        <td><?php echo e($sy->decryption); ?></td>
                        <td>
                            <!-- Thumbnail-->
                            <img src="<?php echo e(asset('imagesuperiority/' . $sy->image_superiority)); ?>" 
                                alt="Activity Photo" 
                                style="max-width: 100px; height: auto; cursor: pointer;" 
                                data-toggle="modal" data-target="#imageModal<?php echo e($sy->id_superiority); ?>">

                            <!-- Modal gambar -->
                            <div class="modal fade" id="imageModal<?php echo e($sy->id_superiority); ?>" tabindex="-1" role="dialog" aria-labelledby="imageModalLabel<?php echo e($sy->id_superiority); ?>" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="imageModalLabel<?php echo e($sy->id_superiority); ?>">Preview Gambar</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body text-center">
                                            <img src="<?php echo e(asset('imagesuperiority/' . $sy->image_superiority)); ?>" 
                                                alt="Full Image" 
                                                class="img-fluid">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#edit<?php echo e($sy->id_superiority); ?>">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delete<?php echo e($sy->id_superiority); ?>">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="newAddModal" tabindex="-1" role="dialog" aria-labelledby="newAddModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="newAddModalLabel">Add New Superioritys</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

           <form action="<?php echo e(route('freecool_bac.addsuperiority')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body"> 

                    <div class="form-group">
                        <label for="title">Title</label>
                        <input type="text" class="form-control" id="title" name="title" placeholder="Title" required>
                    </div>

                    <div class="form-group"> 
                        <label for="decryption">Decryption</label>
                        <textarea class="form-control" id="decryption" name="decryption" placeholder="Decryption" rows="4" required></textarea>
                    </div>                    

                    <div class="form-group">
                        <label for="image_superiority">Image Superiority</label>
                        <input type="file" class="form-control-file" id="image_superiority" name="image_superiority" accept=".jpg,.jpeg,.png,.svg,.gif" onchange="image_superiorityPreview(event)" required>
                        <div id="image_superiorityPreview" style="margin-top: 10px;"></div>
                    </div> 
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add</button> 
                </div> 
            </form>

        </div>
    </div>
</div>

<!-- Modal Edit -->
<?php $__currentLoopData = $superioritys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="edit<?php echo e($sy->id_superiority); ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel<?php echo e($sy->id_superiority); ?>" aria-hidden="true">
    <div class="modal-dialog" role="document"> 
        <div class="modal-content"> 
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel<?php echo e($sy->id_superiority); ?>">Edit Superiority</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <form action="<?php echo e(route('freecool_bac.editsuperiority_action', $sy->id_superiority)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>

                <div class="modal-body"> 
                    <div class="form-group">
                        <label for="title">Title</label>
                        <input type="text" class="form-control" id="title" name="title" value="<?php echo e($sy->title); ?>">
                    </div>

                    <div class="form-group"> 
                        <label for="decryption">Decryption</label>
                        <textarea class="form-control" id="decryption" name="decryption" rows="4" required><?php echo e($sy->decryption); ?></textarea>
                    </div>


                    <div class="form-group"> 
                        <label for="image_superiority">Image Superiority</label>
                        <input type="file" class="form-control-file" id="image_superiority<?php echo e($sy->id_superiority); ?>" name="image_superiority" accept=".jpg,.jpeg,.png,.svg,.gif" onchange="previewImage(event, <?php echo e($sy->id_superiority); ?>)">
                        
                        <div id="image_superiorityPreview<?php echo e($sy->id_superiority); ?>" style="margin-top: 10px;">
                            <?php if($sy->image_superiority): ?> 
                                <img src="<?php echo e(asset('imagesuperiority/' . $sy->image_superiority)); ?>" alt="Current Image" style="max-width: 100px;"> 
                            <?php endif; ?> 
                        </div> 
                    </div>
 
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<!-- Modal Delete -->
<?php $__currentLoopData = $superioritys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sy): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="delete<?php echo e($sy->id_superiority); ?>" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel<?php echo e($sy->id_superiority); ?>" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel<?php echo e($sy->id_superiority); ?>">Delete <?php echo e($sy->title); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h5>Are you sure you want to delete this data...?</h5>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <a href="<?php echo e(route('freecool_bac.deletesuperiority', $sy->id_superiority)); ?>" class="btn btn-danger">Delete</a>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    function image_superiorityPreview(event) {
        const preview = document.getElementById('image_superiorityPreview');
        const file = event.target.files[0];
    
        if (!file) return;
    
        const isImage = file.type.startsWith('image/');
        preview.innerHTML = '';
    
        if (isImage) {
            const img = document.createElement('img');
            img.src = URL.createObjectURL(file);
            img.style.maxHeight = '150px';
            preview.appendChild(img);
        } else {
            const span = document.createElement('span');
            span.textContent = `Selected file: ${file.name}`;
            preview.appendChild(span);
        }
    }
</script>


<script>
function previewImage(event, id) {
    const reader = new FileReader();
    reader.onload = function() {
        const output = document.getElementById('image_superiorityPreview' + id);
        output.innerHTML = '<img src="' + reader.result + '" style="max-width: 100px;">';
    };
    if (event.target.files[0]) {
        reader.readAsDataURL(event.target.files[0]);
    }
}
</script>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\laravel\bac\resources\views/freecool_bac/index.blade.php ENDPATH**/ ?>