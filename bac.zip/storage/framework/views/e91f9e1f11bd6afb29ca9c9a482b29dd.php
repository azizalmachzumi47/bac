<?php echo e($slot); ?>

<?php /**PATH D:\project\laravel\myproject\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>