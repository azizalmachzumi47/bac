<link rel="stylesheet" href="<?php echo e(asset('assets/css/alert.css')); ?>">
<div id="message-container"></div>
<script src="<?php echo e(asset('assets/js/alert.js')); ?>"></script>

<?php if(session('success')): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            showMessage('<?php echo e(session('success')); ?>');
        });
    </script>
<?php endif; ?>

<?php if(session('error')): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            showError('<?php echo e(session('error')); ?>');
        });
    </script>
<?php endif; ?>

<?php if($errors->any()): ?>
    <script>
        document.addEventListener('DOMContentLoaded', function() {
            let errorMessages = '';
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                errorMessages += '<?php echo e($error); ?>\n';
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            showError(errorMessages);
        });
    </script>
<?php endif; ?><?php /**PATH D:\Project\Laravel\bac\resources\views/fragment/alert.blade.php ENDPATH**/ ?>