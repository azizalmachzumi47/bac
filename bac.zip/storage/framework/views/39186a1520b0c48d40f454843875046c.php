

<?php $__env->startSection('title', 'Company Profile'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <a href="" class="btn btn-primary mb-3" data-toggle="modal" data-target="#newAddModal">
            Add New Service
        </a>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-striped table-bordered first">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Category</th>
                        <th scope="col">Decryption</th>
                        <th scope="col">Address</th>
                        <th scope="col">Activity Date</th>
                        <th scope="col">Activity Photos</th>
                        <th scope="col">Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($loop->iteration); ?></td>
                        <td><?php echo e($sv->category); ?></td>
                        <td><?php echo e($sv->decryption); ?></td>
                        <td><?php echo e($sv->address); ?></td>
                        <td><?php echo e($sv->activity_date); ?></td>
                        <td>
                            <!-- Thumbnail-->
                            <img src="<?php echo e(asset('activityphotos_bac/' . $sv->activity_photos)); ?>" 
                                alt="Activity Photo" 
                                style="max-width: 100px; height: auto; cursor: pointer;" 
                                data-toggle="modal" data-target="#imageModal<?php echo e($sv->id); ?>">

                            <!-- Modal gambar -->
                            <div class="modal fade" id="imageModal<?php echo e($sv->id); ?>" tabindex="-1" role="dialog" aria-labelledby="imageModalLabel<?php echo e($sv->id); ?>" aria-hidden="true">
                                <div class="modal-dialog modal-dialog-centered" role="document">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <h5 class="modal-title" id="imageModalLabel<?php echo e($sv->id); ?>">Preview Gambar</h5>
                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                <span aria-hidden="true">&times;</span>
                                            </button>
                                        </div>
                                        <div class="modal-body text-center">
                                            <img src="<?php echo e(asset('activityphotos_bac/' . $sv->activity_photos)); ?>" 
                                                alt="Full Image" 
                                                class="img-fluid">
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </td>
                        <td>
                            <button class="btn btn-warning btn-sm" data-toggle="modal" data-target="#edit<?php echo e($sv->id_service); ?>">
                                <i class="fas fa-edit"></i>
                            </button>
                            <button class="btn btn-danger btn-sm" data-toggle="modal" data-target="#delete<?php echo e($sv->id_service); ?>">
                                <i class="fas fa-trash"></i>
                            </button>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>

<!-- Modal -->
<div class="modal fade" id="newAddModal" tabindex="-1" role="dialog" aria-labelledby="newAddModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="newAddModalLabel">Add New Service</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

           <form action="<?php echo e(route('service.addservice')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body"> 
                    <div class="form-group">
                        <label for="category">Category</label>
                        <select class="form-control" id="category" name="category" required>
                            <option> -- Category -- </option>
                            <option value="Air Condition Section">Air Condition Section</option>
                            <option value="Refrigerator Section">Refrigerator Section</option>
                            <option value="Civil">Civil</option>
                        </select>
                    </div>

                    <div class="form-group"> 
                        <label for="decryption">Decryption</label>
                        <textarea class="form-control" id="decryption" name="decryption" placeholder="Decryption" rows="4" required></textarea>
                    </div>
       
                    <div class="form-group">
                        <label for="address">Address</label>
                        <textarea class="form-control" id="address" name="address" placeholder="Address" rows="3" required></textarea>
                    </div>

                    <div class="form-group">
                        <label for="activity_date">Activity Date</label>
                        <input type="date" class="form-control" id="activity_date" name="activity_date" placeholder="Activity Date" required>
                    </div>

                    <div class="form-group">
                        <label for="activity_photos">Activity Photos</label>
                        <input type="file" class="form-control-file" id="activity_photos" name="activity_photos" accept=".jpg,.jpeg,.png,.svg,.gif" onchange="activity_photosPreview(event)" required>
                        <div id="activity_photosPreview" style="margin-top: 10px;"></div>
                    </div> 
                </div>
                
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Add</button> 
                </div> 
            </form>

        </div>
    </div>
</div>

<!-- Modal Edit -->
<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="edit<?php echo e($sv->id_service); ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel<?php echo e($sv->id_service); ?>" aria-hidden="true">
    <div class="modal-dialog" role="document"> 
        <div class="modal-content"> 
            <div class="modal-header">
                <h5 class="modal-title" id="editModalLabel<?php echo e($sv->id_service); ?>">Edit Service</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>

            <form action="<?php echo e(route('service.editservice_action', $sv->id_service)); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <?php echo method_field('POST'); ?>

                <div class="modal-body"> 
                    <div class="form-group">
                        <label for="category">Category</label>
                        <select class="form-control" id="category" name="category" required>
                            <option> -- Category -- </option>
                            <option value="Air Condition Section" <?php echo e($sv->category == 'Air Condition Section' ? 'selected' : ''); ?>>Air Condition Section</option>
                            <option value="Refrigerator Section" <?php echo e($sv->category == 'Refrigerator Section' ? 'selected' : ''); ?>>Refrigerator Section</option>
                            <option value="Civil" <?php echo e($sv->category == 'Civil' ? 'selected' : ''); ?>>Civil</option>
                        </select>
                    </div>

                    <div class="form-group"> 
                        <label for="decryption">Decryption</label>
                        <textarea class="form-control" id="decryption" name="decryption" rows="4" required><?php echo e($sv->decryption); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="address">Address</label>
                        <textarea class="form-control" id="address" name="address" rows="3" required><?php echo e($sv->address); ?></textarea>
                    </div>

                    <div class="form-group">
                        <label for="activity_date">Activity Date</label>
                        <input type="date" class="form-control" id="activity_date" name="activity_date" value="<?php echo e($sv->activity_date); ?>" required>
                    </div>

                    <div class="form-group">
                        <label for="activity_photos">Activity Photos</label>
                        <input type="file" class="form-control-file" id="activity_photos<?php echo e($sv->id_service); ?>" name="activity_photos" accept=".jpg,.jpeg,.png,.svg,.gif" onchange="previewImage(event, <?php echo e($sv->id_service); ?>)">
                        <div id="activity_photosPreview<?php echo e($sv->id_service); ?>" style="margin-top: 10px;">
                            <?php if($sv->activity_photos): ?>
                                <img src="<?php echo e(asset('activityphotos_bac/' . $sv->activity_photos)); ?>" alt="Current Image" style="max-width: 100px;">
                            <?php endif; ?>
                        </div>
                    </div> 
                </div>

                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Save changes</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


<!-- Modal Delete -->
<?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="modal fade" id="delete<?php echo e($sv->id_service); ?>" tabindex="-1" role="dialog" aria-labelledby="deleteModalLabel<?php echo e($sv->id_service); ?>" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="deleteModalLabel<?php echo e($sv->id_service); ?>">Delete <?php echo e($sv->category); ?></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <h5>Are you sure you want to delete this data...?</h5>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                <a href="<?php echo e(route('service.deleteservice', $sv->id_service)); ?>" class="btn btn-danger">Delete</a>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<script>
    function activity_photosPreview(event) {
        const preview = document.getElementById('activity_photosPreview');
        const file = event.target.files[0];
    
        if (!file) return;
    
        const isImage = file.type.startsWith('image/');
        preview.innerHTML = '';
    
        if (isImage) {
            const img = document.createElement('img');
            img.src = URL.createObjectURL(file);
            img.style.maxHeight = '150px';
            preview.appendChild(img);
        } else {
            const span = document.createElement('span');
            span.textContent = `Selected file: ${file.name}`;
            preview.appendChild(span);
        }
    }
</script>


<script>
// Mengatur nilai default input date ke tanggal hari ini
document.addEventListener("DOMContentLoaded", function() {
    const today = new Date().toISOString().split('T')[0];
    document.getElementById("activity_date").value = today;
});
</script>


<script>
function previewImage(event, id) {
    const reader = new FileReader();
    reader.onload = function(){
        const output = document.getElementById('activity_photosPreview' + id);
        output.innerHTML = '<img src="' + reader.result + '" style="max-width: 100px;">';
    };
    reader.readAsDataURL(event.target.files[0]);
}
</script>


<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\laravel\bac\resources\views/service/index.blade.php ENDPATH**/ ?>