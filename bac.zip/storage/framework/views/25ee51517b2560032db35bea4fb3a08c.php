

<?php $__env->startSection('title', 'Dashboard User'); ?>

<?php $__env->startSection('content'); ?>
<h1>Selamat Datang di Dashboard User</h1>
<p>Konten untuk user di sini.</p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\project\laravel\myproject\resources\views/user/index.blade.php ENDPATH**/ ?>