

<?php $__env->startSection('title', 'Role'); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-header">
        <h5>Role: <?php echo e($role->role); ?></h5>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table id="example4" class="table table-striped table-bordered" style="width:100%">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Menu</th>
                        <th scope="col">Access</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $menu; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <th scope="row"><?php echo e($index + 1); ?></th>
                        <td><?php echo e($m->menu); ?></td>
                        <td>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox"
                                    <?php echo e(check_access($role->id, $m->id) ? 'checked' : ''); ?>

                                    data-role="<?php echo e($role->id); ?>" data-menu="<?php echo e($m->id); ?>">
                            </div>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Project\Laravel\bac\resources\views/admin/roleaccess.blade.php ENDPATH**/ ?>